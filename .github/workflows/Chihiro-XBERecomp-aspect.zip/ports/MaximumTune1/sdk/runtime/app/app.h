#pragma once
#include <cstdint>
#include <filesystem>
#include <mutex>
#include <string>
#include <utility>
#include <vector>

namespace input {
struct Pad;
}

// the host side: window, settings
namespace app {

enum class DisplayMode : uint32_t { Fullscreen, Borderless, Windowed };

struct Settings {
    DisplayMode display_mode = DisplayMode::Borderless;
    uint32_t width = 0, height = 0;  // 0 is the desktop mode
    uint32_t render_percent = 100;   // of the output height
#ifdef __ANDROID__
    uint32_t fps_cap = 0;            // 0 unlimited
#else
    uint32_t fps_cap = 60;           // 0 unlimited
#endif
#ifdef __ANDROID__
    // mobile: default to uncapped to avoid artificial frame limits
#endif
#ifdef __ANDROID__
    bool vsync = false;
#else
    bool vsync = true;
#endif
    uint32_t aspect = 0;             // 0 auto, 1 4:3, 2 16:9, 3 stretch to screen
    uint32_t aniso = 0;              // 0 as the game asks
    std::string join_ip;                   // co-op: a host past the LAN the system link search also asks
};

Settings& Get();
void Load();
void Save();
void LogSettings();  // every setting, as the settings file has them
void LogSystem();    // the machine and the settings, at a run's start
void ApplyDisplay();  // any thread
struct Mode {
    uint32_t width, height;
};
Mode Desktop();
Mode Output();
float RenderScale(uint32_t guest_height);
// the output is 3:2 or wider: the console reports a widescreen TV and the frame is shown 16:9, else 4:3 as on a 4:3 TV
bool Widescreen();

std::filesystem::path ExeDir();
// the game in assets (game_files.cpp): its folder and this executable's xbe, from the extracted files or a disc
// image (.iso), which it mounts as D:; false after telling the player what is missing
struct GameFiles {
    std::filesystem::path dir;
    std::vector<uint8_t> xbe;
};
bool FindGame(GameFiles& game);
int Instance();  // --instance N on the command line, 0 without: a second copy on this PC for system link tests
void* Window();  // HWND on Windows, SDL_Window* on Linux
void Quit();     // any thread: closes the game window, which ends the run
bool Unfocused();  // the game window is shown and in the background or minimized
// message boxes over the game, any thread
void ShowError(const wchar_t* text);
bool AskYesNo(const wchar_t* text);  // false: no, the default

// Linux, the SDL3 host (main_sdl.cpp): what a Vulkan renderer needs of the window, from its own thread
std::vector<const char*> VulkanInstanceExtensions();
// the window's surface on instance (a VkInstance), made on the window thread; false without one
bool CreateVulkanSurface(void* instance, uint64_t* surface);
void WindowPixels(uint32_t& w, uint32_t& h);  // the window's drawable size, any thread
bool GraphicsMenuOpen();
void ToggleGraphicsMenu();
void SetGraphicsMenuOpen(bool open);  // custom panels share the same pause state
void DrawGraphicsMenu(double fps);
void UiNewFrame();  // ImGui's platform frame (display size, time), UiLock held; Windows: ImGui_ImplWin32_NewFrame
// WM_INPUT's lp on Linux: the relative mouse motion and wheel since the last one, as raw input reports them
struct RawMouse {
    int32_t dx, dy;
    int32_t wheel;  // notches, up positive
};
// boot splash: GameInfo::splash .bmp or .png beside the exe, up before the game window
bool OpenSplash();        // window thread, at launch; false without one, and the game window opens at once
void SplashFirstFrame();  // the game's first Swap: waits out the splash's minimum, then opens the game window
void CloseSplash();       // window thread
void OpenGameWindow(bool apply = true);  // any thread but the window thread's; returns once the window is up
// relaunched: the previous instance keeps its window up until this one has shown its first frames (handover.cpp)
bool StartHandover();   // window thread, at launch; true: the game window starts hidden
bool HandingOver();
void FinishHandover();  // any thread but the window thread's: opens the game window, lets the old instance go

// held around ImGui: the window thread's messages and the renderer's frame
std::recursive_mutex& UiLock();

// what the game repo defines once
struct Option {  // a setting in the settings file, flag or value
    const char* key;
    bool* flag;
    uint32_t* value;
};
struct GameInfo {
    const wchar_t* title;        // window and splash
    const wchar_t* short_title;  // message boxes
    const wchar_t* name;         // window classes, crash dumps, handover event
    const char* log;             // log prefix
    const char* settings;        // settings file beside the exe
    const wchar_t* splash;       // .bmp or .png beside the exe
    const wchar_t* missing;      // message when neither the game files nor a disc image are found
    std::vector<std::pair<const char*, const char*>> images;  // xbe file name, executable name
    std::vector<Option> options;
    // the settings file's toml::table, for what options cannot hold
    void (*load)(const void* table);
    void (*save)(void* table);
    void (*init)();                // after the settings load, before the window and boot
    void (*loaded)();              // image in memory, before its entry runs
    void (*window)(void* hwnd);    // the game window is up, before boot
    // window thread, each message after ImGui's; true returns result instead of the host's handling
    bool (*message)(void* hwnd, uint32_t msg, uintptr_t wp, intptr_t lp, intptr_t* result);
    void (*ui)(double fps);        // each frame inside the ImGui frame, UiLock held
    void (*pad)(int port, input::Pad& pad);  // a polled pad before the game gets it
    void (*rumble)(int port, uint16_t& left, uint16_t& right);
    // the keyboard plays as the first controller (core/keyboard_pad.h); off for a game with its own keyboard controls
    bool keyboard_pad = true;
    void (*toggle_menu)() = nullptr;  // optional title-specific settings panel
};
extern const GameInfo kGame;

// sleeps out the rest of the frame for the fps cap
void Pace();

}  // namespace app
