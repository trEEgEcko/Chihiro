package org.xberecomp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.SparseIntArray;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import org.libsdl.app.SDLActivity;

/** Small arcade panel. Aim touches reach SDL; panel touches only press keys. */
final class ArcadeControls extends View {
    private static final int GAME = -1;
    private final String kind;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ArrayList<Control> buttons = new ArrayList<>();
    private final SparseIntArray owners = new SparseIntArray();
    private final SparseArray<float[]> fingers = new SparseArray<>();
    private int device;

    private static final int G_NONE = 0, G_PAUSE = 1, G_ASPECT = 2, G_MENU = 3, G_VIEW = 4;
    private static final int ACT_NONE = 0, ACT_QUICK = 1, ACT_PAUSE = 2;
    private int layoutMode;          // 0 pedals on the right, 1 left-handed
    private boolean pausedNow;
    private boolean dark = true;   // Quick options follow the phone's light or dark theme
    private float opacity = .92f;
    private android.content.SharedPreferences prefs;
    private final boolean hud;
    private Bitmap coinUp, coinDown, startUp, startDown, reloadImg;
    private Bitmap leftUp, leftDown, rightUp, rightDown, brakeUp, brakeDown, gasUp, gasDown;

    private static final class Control {
        final String label;
        final int key;
        final RectF rect;   // touch area
        RectF vis;          // drawn area (defaults to rect)
        Bitmap up, down;
        int glyph = G_NONE;
        int idleAlpha = 235;
        int action = ACT_NONE;
        boolean hidden;
        int held;
        Control(String label, int key, RectF rect) {
            this.label = label; this.key = key; this.rect = rect; this.vis = rect;
        }
    }

    private Bitmap[] loadPair(String idleName, String downName) {
        Bitmap idle = load(idleName, false), down = load(downName, false);
        if (idle == null) return new Bitmap[] {null, null};
        int w = idle.getWidth(), h = idle.getHeight(), x0 = w, y0 = h, x1 = -1, y1 = -1;
        for (int y = 0; y < h; ++y)
            for (int x = 0; x < w; ++x)
                if ((idle.getPixel(x, y) >>> 24) > 8) {
                    if (x < x0) x0 = x; if (x > x1) x1 = x;
                    if (y < y0) y0 = y; if (y > y1) y1 = y;
                }
        if (x1 < x0 || y1 < y0) return new Bitmap[] {idle, down};
        Bitmap a = Bitmap.createBitmap(idle, x0, y0, x1 - x0 + 1, y1 - y0 + 1);
        Bitmap b = down == null || down.getWidth() != w || down.getHeight() != h ? a
                 : Bitmap.createBitmap(down, x0, y0, x1 - x0 + 1, y1 - y0 + 1);
        return new Bitmap[] {a, b};
    }

    private Bitmap load(String name, boolean trim) {
        int id = getResources().getIdentifier(name, "drawable", getContext().getPackageName());
        if (id == 0) return null;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        Bitmap b = BitmapFactory.decodeResource(getResources(), id, o);
        if (b == null || !trim) return b;
        int w = b.getWidth(), h = b.getHeight(), x0 = w, y0 = h, x1 = -1, y1 = -1;
        for (int y = 0; y < h; ++y)
            for (int x = 0; x < w; ++x)
                if ((b.getPixel(x, y) >>> 24) > 8) {
                    if (x < x0) x0 = x; if (x > x1) x1 = x;
                    if (y < y0) y0 = y; if (y > y1) y1 = y;
                }
        if (x1 < x0 || y1 < y0) return b;
        return Bitmap.createBitmap(b, x0, y0, x1 - x0 + 1, y1 - y0 + 1);
    }

    ArcadeControls(Context context, String kind) {
        super(context);
        this.kind = kind;
        this.hud = kind.equals("gun-hotd3") || kind.equals("gun-vcop3") || kind.equals("driving");
        prefs = context.getSharedPreferences("game", Context.MODE_PRIVATE);
        opacity = prefs.getFloat("hud_opacity", kind.equals("driving") ? .31f : .92f);
        layoutMode = prefs.getInt("hud_layout", 0);
        if (hud) {
            Bitmap[] p = loadPair("btn_coin_idle", "btn_coin_pressed"); coinUp = p[0]; coinDown = p[1];
            p = loadPair("btn_start_idle", "btn_start_pressed"); startUp = p[0]; startDown = p[1];
            if (kind.equals("driving")) {
                p = loadPair("btn_left_idle", "btn_left_pressed"); leftUp = p[0]; leftDown = p[1];
                p = loadPair("btn_right_idle", "btn_right_pressed"); rightUp = p[0]; rightDown = p[1];
                p = loadPair("pedal_brake_idle", "pedal_brake_pressed"); brakeUp = p[0]; brakeDown = p[1];
                p = loadPair("pedal_gas_idle", "pedal_gas_pressed"); gasUp = p[0]; gasDown = p[1];
            } else {
                reloadImg = load("btn_reload", false);
            }
        }
        setFocusable(false);
        setContentDescription("Arcade controls");
    }

    private void add(String label, int key, float x, float y, float w, float h) {
        buttons.add(new Control(label, key, new RectF(x, y, x + w, y + h)));
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        releaseAll();
        buttons.clear();
        if (hud) { if (kind.equals("driving")) layoutDriving(w, h); else layoutHud(w, h); return; }
        float u = Math.min(w / 13f, h / 6f), gap = u * .12f;
        float top = gap, bw = u * 1.45f, bh = u * .62f;
        if (!kind.equals("gun-vcop3")) add("Coin", KeyEvent.KEYCODE_DEL, gap, top, bw, bh);
        add("Start", KeyEvent.KEYCODE_ENTER,
            kind.equals("gun-vcop3") ? gap : gap * 2 + bw, top, bw, bh);
        add("Settings", KeyEvent.KEYCODE_F10, w - bw - gap, top, bw, bh);
        if (kind.startsWith("gun-")) {
            add("Reload", KeyEvent.KEYCODE_X, w - bw - gap, h - bh - gap, bw, bh);
            if (kind.equals("gun-vcop3"))
                add("Slow", KeyEvent.KEYCODE_A, w - bw * 2 - gap * 2, h - bh - gap, bw, bh);
        } else {
            float bottom = h - u - gap;
            add("Left", KeyEvent.KEYCODE_DPAD_LEFT, gap, bottom, u, u);
            add("Right", KeyEvent.KEYCODE_DPAD_RIGHT, gap * 2 + u, bottom, u, u);
            add("Brake", KeyEvent.KEYCODE_Q, w - u * 2 - gap * 2, bottom, u, u);
            add("Gas", KeyEvent.KEYCODE_W, w - u - gap, bottom, u, u);
        }
    }

    /** Same arrangement as the HOTD2 build: icons top right, reload lower left, coin/start lower right. */
    private void layoutHud(int w, int h) {
        float pad = h * .02f;
        // top-right cluster: pause, aspect, menu
        float hit = h * .095f, cy = h * .069f;
        float[] cx = {w * .869f, w * .919f, w * .969f};
        int[] keys = {KeyEvent.KEYCODE_F8, KeyEvent.KEYCODE_F9, KeyEvent.KEYCODE_F10};
        String[] names = {"Pause", "Aspect", "Menu"};
        int[] glyphs = {G_PAUSE, G_ASPECT, G_MENU};
        for (int i = 0; i < 3; ++i) {
            Control c = new Control(names[i], keys[i],
                new RectF(cx[i] - hit / 2, cy - hit / 2, cx[i] + hit / 2, cy + hit / 2));
            c.glyph = glyphs[i];
            if (glyphs[i] == G_MENU) c.action = ACT_QUICK;
            if (glyphs[i] == G_PAUSE) c.action = ACT_PAUSE;
            buttons.add(c);
        }
        // reload: square, lower left
        float rs = h * .282f, rl = w * .027f, rb = h - h * .063f;
        Control reload = new Control("Reload", KeyEvent.KEYCODE_X, new RectF(rl, rb - rs, rl + rs, rb));
        reload.up = reloadImg; reload.down = reloadImg;
        buttons.add(reload);
        // coin / start: lower right pills
        float pw = h * .16f, cyp = h * .942f;
        if (kind.equals("gun-vcop3")) {
            float sw = pw, sh = pw * .36f;
            add("SLOW", KeyEvent.KEYCODE_A, w * .816f - sw / 2, cyp - sh / 2, sw, sh);
        } else {
            addPill("Coin", KeyEvent.KEYCODE_DEL, coinUp, coinDown, w * .816f, cyp, pw, pad);
        }
        addPill("Start", KeyEvent.KEYCODE_ENTER, startUp, startDown, w * .903f, cyp, pw, pad);
    }

    /** OutRun 2 layout (2400x1080 reference): arrows left, coin/start centre, pedals right. */
    private void layoutDriving(int w, int h) {
        float s = h / 1080f, sx = w / 2400f;
        float hit = h * .095f, cy = h * .074f;
        float[] cx = {1948f * sx, 2070f * sx, 2195f * sx};
        int[] keys = {KeyEvent.KEYCODE_F8, KeyEvent.KEYCODE_F9, KeyEvent.KEYCODE_F10};
        String[] names = {"Pause", "Aspect", "Menu"};
        int[] glyphs = {G_PAUSE, G_ASPECT, G_MENU};
        for (int i = 0; i < 3; ++i) {
            Control c = new Control(names[i], keys[i],
                new RectF(cx[i] - hit / 2, cy - hit / 2, cx[i] + hit / 2, cy + hit / 2));
            c.glyph = glyphs[i];
            if (glyphs[i] == G_MENU) c.action = ACT_QUICK;
            if (glyphs[i] == G_PAUSE) c.action = ACT_PAUSE;
            buttons.add(c);
        }
        float pad = 14f * s;
        // left-handed: the steering arrows and the pedals trade sides
        float dArrows = layoutMode == 1 ? (2231f - 728f) * sx : 0f;
        float dPedals = layoutMode == 1 ? (152f - 1742f) * sx : 0f;
        // steering arrows: touch areas meet in the middle
        addImage("Left", KeyEvent.KEYCODE_DPAD_LEFT, leftUp, leftDown, 152f * sx + dArrows, 746f * s, 1f * s, pad, 0f, 20f * sx);
        addImage("Right", KeyEvent.KEYCODE_DPAD_RIGHT, rightUp, rightDown, 457f * sx + dArrows, 746f * s, 1f * s, pad, 20f * sx, 0f);
        // pedals
        addImage("Brake", KeyEvent.KEYCODE_Q, brakeUp, brakeDown, 1742f * sx + dPedals, 855f * s, .5f * s, pad, pad, pad);
        addImage("Gas", KeyEvent.KEYCODE_W, gasUp, gasDown, 2030f * sx + dPedals, 555f * s, .49f * s, pad, pad, pad);
        // coin / start
        addImage("Coin", KeyEvent.KEYCODE_DEL, coinUp, coinDown, 977f * sx, 977f * s, .92f * s, pad, pad, pad);
        addImage("Start", KeyEvent.KEYCODE_ENTER, startUp, startDown, 1267f * sx, 977f * s, .92f * s, pad, pad, pad);
    }

    private void addImage(String label, int key, Bitmap up, Bitmap down, float left, float top, float scale,
                          float padV, float padL, float padR) {
        float bw = up != null ? up.getWidth() * scale : 150f * scale;
        float bh = up != null ? up.getHeight() * scale : 60f * scale;
        RectF vis = new RectF(left, top, left + bw, top + bh);
        Control c = new Control(label, key, new RectF(left - padL, top - padV, left + bw + padR, top + bh + padV));
        c.vis = vis; c.up = up; c.down = down; c.idleAlpha = 80;
        buttons.add(c);
    }

    private void addPill(String label, int key, Bitmap up, Bitmap down, float cx, float cy, float pw, float pad) {
        float ph = up != null ? pw * up.getHeight() / up.getWidth() : pw * .36f;
        RectF vis = new RectF(cx - pw / 2, cy - ph / 2, cx + pw / 2, cy + ph / 2);
        RectF area = new RectF(vis.left - pad, vis.top - pad, vis.right + pad, vis.bottom + pad);
        Control c = new Control(label, key, area);
        c.vis = vis; c.up = up; c.down = down;
        buttons.add(c);
    }

    private void drawGlyph(Canvas canvas, Control c) {
        float cx = c.rect.centerX(), cy = c.rect.centerY(), r = c.rect.height() * .26f;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(3f, c.rect.height() * .06f));
        paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(c.held > 0 ? 0xFFFF5050 : Color.WHITE);
        paint.setAlpha((int) (255 * Math.max(.55f, opacity)));
        paint.setShadowLayer(4f, 0f, 2f, 0xAA000000);
        if (c.glyph == G_PAUSE) {
            paint.setStyle(Paint.Style.FILL);
            if (pausedNow) {        // paused: show play
                Path tri = new Path();
                tri.moveTo(cx - r * .7f, cy - r * 1.1f); tri.lineTo(cx - r * .7f, cy + r * 1.1f); tri.lineTo(cx + r * .9f, cy);
                tri.close();
                canvas.drawPath(tri, paint);
            } else {                // running: show pause
                canvas.drawRect(cx - r * .8f, cy - r, cx - r * .3f, cy + r, paint);
                canvas.drawRect(cx + r * .3f, cy - r, cx + r * .8f, cy + r, paint);
            }
        } else if (c.glyph == G_ASPECT) {
            float k = r * .55f;
            float[][] corners = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
            for (float[] p : corners) {
                float px = cx + p[0] * r, py = cy + p[1] * r;
                canvas.drawLine(px, py, px - p[0] * k, py, paint);
                canvas.drawLine(px, py, px, py - p[1] * k, paint);
            }
        } else if (c.glyph == G_VIEW) {
            float bw = r * 1.5f, bh = r * 1.05f;
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawRoundRect(new RectF(cx - bw, cy - bh * .8f, cx + bw, cy + bh), r * .25f, r * .25f, paint);
            canvas.drawLine(cx - bw * .45f, cy - bh * .8f, cx - bw * .3f, cy - bh * 1.15f, paint);
            canvas.drawLine(cx - bw * .3f, cy - bh * 1.15f, cx + bw * .3f, cy - bh * 1.15f, paint);
            canvas.drawLine(cx + bw * .3f, cy - bh * 1.15f, cx + bw * .45f, cy - bh * .8f, paint);
            canvas.drawCircle(cx, cy + bh * .1f, r * .55f, paint);
        } else if (c.glyph == G_MENU) {
            for (int i = -1; i <= 1; ++i)
                canvas.drawLine(cx - r, cy + i * r * .75f, cx + r, cy + i * r * .75f, paint);
        }
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.FILL);
    }

    private int hit(float x, float y) {
        for (int i = 0; i < buttons.size(); ++i)
            if (!buttons.get(i).hidden && buttons.get(i).rect.contains(x, y)) return i;
        return GAME;
    }

    private void key(int index, boolean down) {
        if (index < 0) return;
        Control button = buttons.get(index);
        if (button.action == ACT_QUICK) { if (down) post(this::showQuickOptions); return; }
        if (button.action == ACT_PAUSE) { if (down) post(this::togglePause); return; }
        if (down && button.held++ == 0) SDLActivity.onNativeKeyDown(button.key);
        if (!down && button.held > 0 && --button.held == 0) SDLActivity.onNativeKeyUp(button.key);
        invalidate();
    }

    private void touch(int id, int action, float x, float y, float pressure) {
        float nx = x / Math.max(1, getWidth() - 1), ny = y / Math.max(1, getHeight() - 1);
        SDLActivity.onNativeTouch(device, id, action, nx, ny, Math.min(1, pressure));
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
            float[] position = fingers.get(id);
            if (position == null) fingers.put(id, new float[]{x, y});
            else { position[0] = x; position[1] = y; }
        } else fingers.remove(id);
    }

    void releaseAll() {
        for (Control button : buttons) {
            if (button.held > 0) SDLActivity.onNativeKeyUp(button.key);
            button.held = 0;
        }
        for (int i = 0; i < fingers.size(); ++i) {
            float[] pos = fingers.valueAt(i);
            SDLActivity.onNativeTouch(device, fingers.keyAt(i), MotionEvent.ACTION_CANCEL,
                pos[0] / Math.max(1, getWidth() - 1), pos[1] / Math.max(1, getHeight() - 1), 0);
        }
        fingers.clear(); owners.clear(); invalidate();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (event.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE) return false;
        device = event.getDeviceId();
        int action = event.getActionMasked(), at = event.getActionIndex();
        if (action == MotionEvent.ACTION_CANCEL) { releaseAll(); return true; }
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            int id = event.getPointerId(at), owner = hit(event.getX(at), event.getY(at));
            owners.put(id, owner);
            if (owner >= 0) key(owner, true);
            else touch(id, MotionEvent.ACTION_DOWN, event.getX(at), event.getY(at), event.getPressure(at));
        } else if (action == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < event.getPointerCount(); ++i) {
                int id = event.getPointerId(i), owner = owners.get(id, -2);
                if (owner == GAME) touch(id, MotionEvent.ACTION_MOVE, event.getX(i), event.getY(i), event.getPressure(i));
                else if (owner >= 0 && !buttons.get(owner).rect.contains(event.getX(i), event.getY(i))) {
                    key(owner, false); owners.put(id, -2);
                }
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) {
            int id = event.getPointerId(at), owner = owners.get(id, -2);
            if (owner >= 0) key(owner, false);
            else if (owner == GAME) touch(id, MotionEvent.ACTION_UP, event.getX(at), event.getY(at), 0);
            owners.delete(id);
            performClick();
        }
        return true;
    }

    // ---- the native bridge (GameActivity); older libraries without it just ignore these
    private int nget(String key, int fallback) {
        try { return GameActivity.nativeGetSetting(key); } catch (UnsatisfiedLinkError e) { return fallback; }
    }
    private void nset(String key, int value) {
        try { GameActivity.nativeSetSetting(key, value); } catch (UnsatisfiedLinkError e) { }
    }
    private void togglePause() {
        try { GameActivity.nativeTogglePause(); }
        catch (UnsatisfiedLinkError e) { SDLActivity.onNativeKeyDown(KeyEvent.KEYCODE_F8); SDLActivity.onNativeKeyUp(KeyEvent.KEYCODE_F8); }
        postDelayed(() -> { pausedNow = nget("paused", 0) != 0; invalidate(); }, 150);
    }

    private interface Pick { void on(int index); }

    private void shade(android.widget.Button b, boolean on, float d) {
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(on ? 0xFF2F6FDB : dark ? 0xFF2A3447 : 0xFFE3E7EE); bg.setCornerRadius(8 * d);
        b.setBackground(bg);
        b.setTextColor(on || dark ? Color.WHITE : 0xFF1F2937);
    }

    private android.widget.Button pill(Context ctx, String text, float d, boolean on) {
        android.widget.Button b = new android.widget.Button(ctx);
        b.setText(text); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTextSize(11);
        b.setMinHeight(0); b.setMinimumHeight(0); b.setMinWidth(0); b.setMinimumWidth(0);
        b.setPadding((int) (6 * d), 0, (int) (6 * d), 0);
        shade(b, on, d);
        return b;
    }

    /** a titled row of radio-style pills; the chosen one is blue */
    private android.widget.LinearLayout group(Context ctx, float d, String title, String[] labels, int selected, Pick pick) {
        android.widget.LinearLayout box = new android.widget.LinearLayout(ctx);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(0, (int) (5 * d), 0, 0);
        android.widget.TextView t = new android.widget.TextView(ctx);
        t.setText(title); t.setTextColor(dark ? 0xFF9FB3CC : 0xFF5B6678); t.setTextSize(11);
        box.addView(t);
        android.widget.LinearLayout row = new android.widget.LinearLayout(ctx);
        row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        final android.widget.Button[] btns = new android.widget.Button[labels.length];
        for (int i = 0; i < labels.length; ++i) {
            final int index = i;
            btns[i] = pill(ctx, labels[i], d, i == selected);
            btns[i].setOnClickListener(v -> {
                for (int j = 0; j < btns.length; ++j) shade(btns[j], j == index, d);
                pick.on(index);
            });
            android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(0, (int) (28 * d), 1f);
            lp.topMargin = (int) (3 * d);
            lp.rightMargin = i + 1 < labels.length ? (int) (4 * d) : 0;
            row.addView(btns[i], lp);
        }
        box.addView(row);
        return box;
    }

    private static int indexOf(int[] values, int v, int fallback) {
        for (int i = 0; i < values.length; ++i) if (values[i] == v) return i;
        return fallback;
    }

    private void showQuickOptions() {
        if (!(getContext() instanceof android.app.Activity)) return;
        final android.app.Activity activity = (android.app.Activity) getContext();
        if (activity.isFinishing() || activity.isDestroyed()) return;
        releaseAll();
        pausedNow = nget("paused", 0) != 0;
        dark = (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
               == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        if (nget("display", 0) != 0) nset("display", 0);   // always fullscreen
        final float d = getResources().getDisplayMetrics().density;
        final android.app.Dialog dialog = new android.app.Dialog(activity);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        android.widget.LinearLayout card = new android.widget.LinearLayout(activity);
        card.setOrientation(android.widget.LinearLayout.VERTICAL);
        card.setPadding((int) (16 * d), (int) (12 * d), (int) (16 * d), (int) (12 * d));
        android.graphics.drawable.GradientDrawable cardBg = new android.graphics.drawable.GradientDrawable();
        cardBg.setColor(dark ? 0xF2151B26 : 0xF2FFFFFF); cardBg.setCornerRadius(14 * d);
        cardBg.setStroke((int) Math.max(1, d), dark ? 0x33FFFFFF : 0x33000000);
        card.setBackground(cardBg);

        android.widget.TextView title = new android.widget.TextView(activity);
        title.setText("Quick options  \u00b7  v3"); title.setTextColor(dark ? Color.WHITE : 0xFF111827); title.setTextSize(16);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(title);

        // Exit game: leaves the app completely
        android.widget.Button exit = pill(activity, "Exit game", d, false);
        android.graphics.drawable.GradientDrawable exitBg = new android.graphics.drawable.GradientDrawable();
        exitBg.setColor(0xFFB3261E); exitBg.setCornerRadius(8 * d); exit.setBackground(exitBg); exit.setTextColor(Color.WHITE);
        exit.setOnClickListener(v -> { dialog.dismiss(); GameActivity.restarting = false; activity.finishAndRemoveTask(); });
        android.widget.LinearLayout.LayoutParams exitLp = new android.widget.LinearLayout.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT, (int) (30 * d));
        exitLp.topMargin = (int) (8 * d);
        card.addView(exit, exitLp);

        // current native values; changes wait for "Apply and save"
        final String[] keys = {"height", "scale", "aspect", "aniso", "fps"};
        final int[] resVals = {480, 720, 1080}, scaleVals = {50, 100, 150}, aspVals = {0, 1, 2, 3},
                    anisoVals = {2, 4, 8, 16}, fpsVals = {30, 60, 90, 120, 144, 0};
        final int[] pending = {nget("height", 0), nget("scale", 100), nget("aspect", 0), nget("aniso", 2), nget("fps", 60)};
        final int[] original = pending.clone();

        card.addView(group(activity, d, "Output resolution", new String[] {"480p", "720p", "1080p"},
            indexOf(resVals, pending[0], 2), i -> pending[0] = resVals[i]));
        card.addView(group(activity, d, "Render scale", new String[] {"50%", "100%", "150%"},
            pending[1] <= 75 ? 0 : pending[1] <= 125 ? 1 : 2, i -> pending[1] = scaleVals[i]));
        card.addView(group(activity, d, "Aspect ratio", new String[] {"4:3 Native", "16:9 Wide", "21:9 Ultrawide", "Fit screen"},
            indexOf(aspVals, pending[2], 0), i -> pending[2] = aspVals[i]));
        card.addView(group(activity, d, "Texture filtering", new String[] {"2x", "4x", "8x", "16x"},
            indexOf(anisoVals, pending[3], 0), i -> pending[3] = anisoVals[i]));
        card.addView(group(activity, d, "Frame rate", new String[] {"30", "60", "90", "120", "144", "Unlimited"},
            indexOf(fpsVals, pending[4], 1), i -> pending[4] = fpsVals[i]));

        // HUD: opacity, handedness, screen flip (these act at once)
        final android.widget.TextView opacityLabel = new android.widget.TextView(activity);
        opacityLabel.setTextColor(dark ? 0xFF9FB3CC : 0xFF5B6678); opacityLabel.setTextSize(11);
        opacityLabel.setText("HUD opacity  " + Math.round(opacity * 100) + "%");
        opacityLabel.setPadding(0, (int) (8 * d), 0, 0);
        card.addView(opacityLabel);
        android.widget.SeekBar bar = new android.widget.SeekBar(activity);
        bar.setMax(90); bar.setProgress(Math.max(0, Math.min(90, Math.round(opacity * 100) - 10)));
        bar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar sb, int progress, boolean fromUser) {
                opacity = (progress + 10) / 100f;
                opacityLabel.setText("HUD opacity  " + (progress + 10) + "%");
                invalidate();
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar sb) {}
            @Override public void onStopTrackingTouch(android.widget.SeekBar sb) {
                prefs.edit().putFloat("hud_opacity", opacity).apply();
            }
        });
        card.addView(bar);
        if (kind.equals("driving"))
            card.addView(group(activity, d, "HUD layout", new String[] {"Right-handed", "Left-handed"}, layoutMode, i -> {
                layoutMode = i;
                prefs.edit().putInt("hud_layout", layoutMode).apply();
                onSizeChanged(getWidth(), getHeight(), 0, 0);
                invalidate();
            }));
        final android.widget.Button flip = pill(activity, "Flip screen 180\u00b0", d, false);
        flip.setOnClickListener(v -> {
            boolean flipped = !prefs.getBoolean("flip_screen", false);
            prefs.edit().putBoolean("flip_screen", flipped).apply();
            activity.setRequestedOrientation(flipped ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
                                                     : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        });
        android.widget.LinearLayout.LayoutParams flipLp = new android.widget.LinearLayout.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT, (int) (28 * d));
        flipLp.topMargin = (int) (6 * d);
        card.addView(flip, flipLp);

        if (kind.equals("gun-hotd3")) {   // debug switches for the black parking stage; they act at once and are not saved
            card.addView(group(activity, d, "Debug: culling", new String[] {"On (normal)", "Off"}, nget("nocull", 0) == 1 ? 1 : 0,
                i -> nset("nocull", i)));
            card.addView(group(activity, d, "Debug: depth test", new String[] {"On (normal)", "Off"}, nget("nodepth", 0) == 1 ? 1 : 0,
                i -> nset("nodepth", i)));
        }
        // Apply and save, Restart game, Close
        final Runnable apply = () -> {
            for (int i = 0; i < keys.length; ++i)
                if (pending[i] != original[i]) { nset(keys[i], pending[i]); original[i] = pending[i]; }
        };
        android.widget.LinearLayout actions = new android.widget.LinearLayout(activity);
        actions.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        String[] names = {"Apply and save", "Restart game", "Close"};
        for (int i = 0; i < 3; ++i) {
            final int which = i;
            android.widget.Button b = pill(activity, names[i], d, i == 0);
            b.setOnClickListener(v -> {
                if (which == 0) {
                    apply.run();
                    android.widget.Toast.makeText(activity, "Saved", android.widget.Toast.LENGTH_SHORT).show();
                } else if (which == 1) { apply.run(); dialog.dismiss(); restartGame(activity); }
                else dialog.dismiss();
            });
            android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(0, (int) (32 * d), 1f);
            lp.rightMargin = i < 2 ? (int) (5 * d) : 0;
            actions.addView(b, lp);
        }
        android.widget.LinearLayout.LayoutParams actLp = new android.widget.LinearLayout.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        actLp.topMargin = (int) (10 * d);
        card.addView(actions, actLp);

        android.widget.ScrollView scroll = new android.widget.ScrollView(activity);
        scroll.addView(card);
        dialog.setContentView(scroll);
        android.view.Window w = dialog.getWindow();
        if (w == null) return;
        w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        w.setDimAmount(.6f);
        android.view.WindowManager.LayoutParams lp = w.getAttributes();
        lp.width = (int) Math.min(getWidth() * .5f, 460 * d);
        lp.height = (int) (getHeight() * .94f);
        lp.gravity = android.view.Gravity.CENTER;
        w.setAttributes(lp);
        // keep the immersive state: show without taking focus, copy the system UI flags, then take focus
        w.setFlags(android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        dialog.show();
        w.getDecorView().setSystemUiVisibility(activity.getWindow().getDecorView().getSystemUiVisibility());
        w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
    }

    /** A fresh process is needed, so reopen the launcher, which starts the game again. */
    private void restartGame(android.app.Activity activity) {
        android.content.Intent intent = activity.getPackageManager().getLaunchIntentForPackage(activity.getPackageName());
        if (intent == null) return;
        GameActivity.restarting = true;   // stop onStop from removing the task that now holds the launcher
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.putExtra("org.xberecomp.AUTOSTART", true);
        activity.startActivity(intent);
    }

    @Override public boolean performClick() { return super.performClick(); }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (Control button : buttons) {
            if (button.hidden) continue;
            if (hud) {
                if (button.glyph != G_NONE) { drawGlyph(canvas, button); continue; }
                Bitmap img = button.held > 0 && button.down != null ? button.down : button.up;
                if (img != null) {
                    paint.setAlpha(button.held > 0 ? Math.max(210, (int) (255 * opacity)) : (int) (255 * opacity));
                    canvas.drawBitmap(img, null, button.vis, paint);
                    paint.setAlpha(255);
                    continue;
                }
            }
            paint.setColor(button.held > 0 ? 0xCC397BC1 : 0x99202938);
            canvas.drawRoundRect(button.rect, 12, 12, paint);
            paint.setColor(Color.WHITE); paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(button.rect.height() * .28f);
            canvas.drawText(button.label, button.rect.centerX(),
                button.rect.centerY() - (paint.ascent() + paint.descent()) / 2, paint);
        }
    }
}
