package org.xberecomp;

import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.widget.Toast;
import org.libsdl.app.SDLActivity;

public class GameActivity extends SDLActivity {
    static volatile boolean restarting;
    private ArcadeControls arcadeControls;

    // the native bridge (app/android_bridge.cpp): settings, pause
    public static native void nativeSetSetting(String key, int value);
    public static native int nativeGetSetting(String key);
    public static native void nativeTogglePause();

    @Override protected void onCreate(android.os.Bundle state) {
        // SDL picks the orientation from the window's size and, on a phone held or locked in portrait, locked the game there;
        // tell it only landscape is wanted (read by SDL as the SDL_ORIENTATIONS hint)
        try { android.system.Os.setenv("SDL_ORIENTATIONS", "LandscapeLeft LandscapeRight", true); } catch (Exception ignored) { }
        // landscape; the sensor only decides when the phone's auto-rotate is on, so a locked phone does not open in portrait
        boolean flip = getSharedPreferences("game", MODE_PRIVATE).getBoolean("flip_screen", false);
        boolean auto = android.provider.Settings.System.getInt(getContentResolver(),
            android.provider.Settings.System.ACCELEROMETER_ROTATION, 0) == 1;
        setRequestedOrientation(flip ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
            : auto ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        super.onCreate(state);
        String controls = PortConfig.controls(this);
        if (!controls.isEmpty() && mLayout != null) {
            arcadeControls = new ArcadeControls(this, controls);
            mLayout.addView(arcadeControls, new android.widget.RelativeLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT));
        }
    }

    @Override protected void onPause() {
        if (arcadeControls != null) arcadeControls.releaseAll();
        super.onPause();
    }
    @Override public boolean dispatchKeyEvent(android.view.KeyEvent event) {
        if (event.getKeyCode() == android.view.KeyEvent.KEYCODE_BUTTON_THUMBR) {
            // Reserve R3 before SDL's per-device mapping. Some Android pads
            // expose stick clicks through the keyboard source instead.
            if (event.getAction() == android.view.KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0)
                SDLActivity.onNativeKeyDown(android.view.KeyEvent.KEYCODE_F10);
            else if (event.getAction() == android.view.KeyEvent.ACTION_UP)
                SDLActivity.onNativeKeyUp(android.view.KeyEvent.KEYCODE_F10);
            return true;
        }
        return super.dispatchKeyEvent(event);
    }
    @Override public void onWindowFocusChanged(boolean focused) {
        if (!focused && arcadeControls != null) arcadeControls.releaseAll();
        super.onWindowFocusChanged(focused);
        if (focused) getWindow().getDecorView().post(() -> {
            if (isFinishing() || isDestroyed()) return;
            try {
                // onCreate can precede Android's foreground UID transition.
                // This optional task-removal guard must never abort startup.
                startService(new android.content.Intent(this, GameSessionService.class));
            } catch (IllegalStateException background) {
                android.util.Log.i("XbeSession", "Session guard deferred until foreground");
            }
        });
    }

    @Override protected void onStop() {
        super.onStop();
        // A new foreground session must boot from clean native state. SDL and
        // the recompiled guest cannot safely reuse a lost Vulkan surface.
        if (!isChangingConfigurations() && !restarting) finishAndRemoveTask();
    }

    @Override protected void onDestroy() {
        try {
            stopService(new android.content.Intent(this, GameSessionService.class));
            super.onDestroy();
        } finally {
            // This Activity owns a dedicated process. Ending it releases every
            // guest thread, GPU allocation, audio stream and open document.
            android.util.Log.i("XbeSession", "Releasing game process " + android.os.Process.myPid());
            android.os.Process.killProcess(android.os.Process.myPid());
        }
    }
    @Override protected void main() {
        nativeSetenv("VCOP3_CONTROLS", getSharedPreferences("game", MODE_PRIVATE).getString("controls", "mouse-controller"));
        nativeSetenv("SEGAGOLF_LANGUAGE", "en");
        String uri = getSharedPreferences("game", MODE_PRIVATE).getString("uri", "");
        String kind = getSharedPreferences("game", MODE_PRIVATE).getString("kind", "iso");
        if (!uri.isEmpty() && kind.equals("folder")) {
            try {
                new NativeFiles(this, Uri.parse(uri)).mount(getSharedPreferences("game", MODE_PRIVATE).getString("name", "Game folder"));
                super.main();
            } catch (Exception error) {
                runOnUiThread(() -> Toast.makeText(this, "Cannot read game folder: " + error.getMessage(), Toast.LENGTH_LONG).show());
            }
            return;
        }
        if (uri.isEmpty()) {
            nativeSetenv("XBE_DISC_FD", "");
            nativeSetenv("XBE_DISC_IMAGE", "");
            super.main();
            return;
        }
        // Keep the document grant open while native code runs. The native disc
        // reader duplicates this descriptor and performs pread on the SD card.
        try (ParcelFileDescriptor image = getContentResolver().openFileDescriptor(Uri.parse(uri), "r")) {
            if (image == null) throw new java.io.IOException("Cannot open the selected game image");
            nativeSetenv("XBE_DISC_FD", Integer.toString(image.getFd()));
            nativeSetenv("XBE_DISC_IMAGE", getSharedPreferences("game", MODE_PRIVATE).getString("name", "Selected SD card image"));
            super.main();
        } catch (Exception error) {
            runOnUiThread(() -> Toast.makeText(this, "Choose your game image again: " + error.getMessage(), Toast.LENGTH_LONG).show());
        } finally {
            nativeSetenv("XBE_DISC_FD", "");
            nativeSetenv("XBE_DISC_IMAGE", "");
        }
    }
}
