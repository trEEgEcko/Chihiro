package org.xberecomp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.SparseIntArray;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import org.libsdl.app.SDLActivity;

/** Small arcade panel. Aim touches reach SDL; panel touches only press keys. */
final class ArcadeControls extends View {
    private static final int GAME = -1;
    private final String kind;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ArrayList<Control> buttons = new ArrayList<>();
    private final SparseIntArray owners = new SparseIntArray();
    private final SparseArray<float[]> fingers = new SparseArray<>();
    private int device;

    private static final int G_NONE = 0, G_PAUSE = 1, G_ASPECT = 2, G_MENU = 3;
    private final boolean hud;
    private Bitmap coinUp, coinDown, startUp, startDown, reloadImg;

    private static final class Control {
        final String label;
        final int key;
        final RectF rect;   // touch area
        RectF vis;          // drawn area (defaults to rect)
        Bitmap up, down;
        int glyph = G_NONE;
        int held;
        Control(String label, int key, RectF rect) {
            this.label = label; this.key = key; this.rect = rect; this.vis = rect;
        }
    }

    private Bitmap load(String name, boolean trim) {
        int id = getResources().getIdentifier(name, "drawable", getContext().getPackageName());
        if (id == 0) return null;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        Bitmap b = BitmapFactory.decodeResource(getResources(), id, o);
        if (b == null || !trim) return b;
        int w = b.getWidth(), h = b.getHeight(), x0 = w, y0 = h, x1 = -1, y1 = -1;
        for (int y = 0; y < h; ++y)
            for (int x = 0; x < w; ++x)
                if ((b.getPixel(x, y) >>> 24) > 8) {
                    if (x < x0) x0 = x; if (x > x1) x1 = x;
                    if (y < y0) y0 = y; if (y > y1) y1 = y;
                }
        if (x1 < x0 || y1 < y0) return b;
        return Bitmap.createBitmap(b, x0, y0, x1 - x0 + 1, y1 - y0 + 1);
    }

    ArcadeControls(Context context, String kind) {
        super(context);
        this.kind = kind;
        this.hud = kind.equals("gun-hotd3");
        if (hud) {
            coinUp = load("btn_coin_idle", true); coinDown = load("btn_coin_pressed", true);
            startUp = load("btn_start_idle", true); startDown = load("btn_start_pressed", true);
            reloadImg = load("btn_reload", false);
        }
        setFocusable(false);
        setContentDescription("Arcade controls");
    }

    private void add(String label, int key, float x, float y, float w, float h) {
        buttons.add(new Control(label, key, new RectF(x, y, x + w, y + h)));
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        releaseAll();
        buttons.clear();
        if (hud) { layoutHud(w, h); return; }
        float u = Math.min(w / 13f, h / 6f), gap = u * .12f;
        float top = gap, bw = u * 1.45f, bh = u * .62f;
        if (!kind.equals("gun-vcop3")) add("Coin", KeyEvent.KEYCODE_DEL, gap, top, bw, bh);
        add("Start", KeyEvent.KEYCODE_ENTER,
            kind.equals("gun-vcop3") ? gap : gap * 2 + bw, top, bw, bh);
        add("Settings", KeyEvent.KEYCODE_F10, w - bw - gap, top, bw, bh);
        if (kind.startsWith("gun-")) {
            add("Reload", KeyEvent.KEYCODE_X, w - bw - gap, h - bh - gap, bw, bh);
            if (kind.equals("gun-vcop3"))
                add("Slow", KeyEvent.KEYCODE_A, w - bw * 2 - gap * 2, h - bh - gap, bw, bh);
        } else {
            float bottom = h - u - gap;
            add("Left", KeyEvent.KEYCODE_DPAD_LEFT, gap, bottom, u, u);
            add("Right", KeyEvent.KEYCODE_DPAD_RIGHT, gap * 2 + u, bottom, u, u);
            add("Brake", KeyEvent.KEYCODE_Q, w - u * 2 - gap * 2, bottom, u, u);
            add("Gas", KeyEvent.KEYCODE_W, w - u - gap, bottom, u, u);
        }
    }

    /** Same arrangement as the HOTD2 build: icons top right, reload lower left, coin/start lower right. */
    private void layoutHud(int w, int h) {
        float pad = h * .02f;
        // top-right cluster: pause, aspect, menu
        float hit = h * .095f, cy = h * .069f;
        float[] cx = {w * .869f, w * .919f, w * .969f};
        int[] keys = {KeyEvent.KEYCODE_F10, KeyEvent.KEYCODE_F9, KeyEvent.KEYCODE_F10};
        String[] names = {"Pause", "Aspect", "Menu"};
        int[] glyphs = {G_PAUSE, G_ASPECT, G_MENU};
        for (int i = 0; i < 3; ++i) {
            Control c = new Control(names[i], keys[i],
                new RectF(cx[i] - hit / 2, cy - hit / 2, cx[i] + hit / 2, cy + hit / 2));
            c.glyph = glyphs[i];
            buttons.add(c);
        }
        // reload: square, lower left
        float rs = h * .282f, rl = w * .027f, rb = h - h * .063f;
        Control reload = new Control("Reload", KeyEvent.KEYCODE_X, new RectF(rl, rb - rs, rl + rs, rb));
        reload.up = reloadImg; reload.down = reloadImg;
        buttons.add(reload);
        // coin / start: lower right pills
        float pw = h * .16f, cyp = h * .942f;
        addPill("Coin", KeyEvent.KEYCODE_DEL, coinUp, coinDown, w * .816f, cyp, pw, pad);
        addPill("Start", KeyEvent.KEYCODE_ENTER, startUp, startDown, w * .903f, cyp, pw, pad);
    }

    private void addPill(String label, int key, Bitmap up, Bitmap down, float cx, float cy, float pw, float pad) {
        float ph = up != null ? pw * up.getHeight() / up.getWidth() : pw * .36f;
        RectF vis = new RectF(cx - pw / 2, cy - ph / 2, cx + pw / 2, cy + ph / 2);
        RectF area = new RectF(vis.left - pad, vis.top - pad, vis.right + pad, vis.bottom + pad);
        Control c = new Control(label, key, area);
        c.vis = vis; c.up = up; c.down = down;
        buttons.add(c);
    }

    private void drawGlyph(Canvas canvas, Control c) {
        float cx = c.rect.centerX(), cy = c.rect.centerY(), r = c.rect.height() * .26f;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(3f, c.rect.height() * .06f));
        paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(c.held > 0 ? 0xFFFF5050 : Color.WHITE);
        paint.setShadowLayer(4f, 0f, 2f, 0xAA000000);
        if (c.glyph == G_PAUSE) {
            Path tri = new Path();
            tri.moveTo(cx - r * 1.1f, cy - r); tri.lineTo(cx - r * 1.1f, cy + r); tri.lineTo(cx - r * .1f, cy);
            tri.close();
            paint.setStyle(Paint.Style.FILL);
            canvas.drawPath(tri, paint);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawRect(cx + r * .3f, cy - r, cx + r * .55f, cy + r, paint);
            canvas.drawRect(cx + r * .85f, cy - r, cx + r * 1.1f, cy + r, paint);
        } else if (c.glyph == G_ASPECT) {
            float k = r * .55f;
            float[][] corners = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
            for (float[] p : corners) {
                float px = cx + p[0] * r, py = cy + p[1] * r;
                canvas.drawLine(px, py, px - p[0] * k, py, paint);
                canvas.drawLine(px, py, px, py - p[1] * k, paint);
            }
        } else if (c.glyph == G_MENU) {
            for (int i = -1; i <= 1; ++i)
                canvas.drawLine(cx - r, cy + i * r * .75f, cx + r, cy + i * r * .75f, paint);
        }
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.FILL);
    }

    private int hit(float x, float y) {
        for (int i = 0; i < buttons.size(); ++i)
            if (buttons.get(i).rect.contains(x, y)) return i;
        return GAME;
    }

    private void key(int index, boolean down) {
        if (index < 0) return;
        Control button = buttons.get(index);
        if (down && button.held++ == 0) SDLActivity.onNativeKeyDown(button.key);
        if (!down && button.held > 0 && --button.held == 0) SDLActivity.onNativeKeyUp(button.key);
        invalidate();
    }

    private void touch(int id, int action, float x, float y, float pressure) {
        float nx = x / Math.max(1, getWidth() - 1), ny = y / Math.max(1, getHeight() - 1);
        SDLActivity.onNativeTouch(device, id, action, nx, ny, Math.min(1, pressure));
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
            float[] position = fingers.get(id);
            if (position == null) fingers.put(id, new float[]{x, y});
            else { position[0] = x; position[1] = y; }
        } else fingers.remove(id);
    }

    void releaseAll() {
        for (Control button : buttons) {
            if (button.held > 0) SDLActivity.onNativeKeyUp(button.key);
            button.held = 0;
        }
        for (int i = 0; i < fingers.size(); ++i) {
            float[] pos = fingers.valueAt(i);
            SDLActivity.onNativeTouch(device, fingers.keyAt(i), MotionEvent.ACTION_CANCEL,
                pos[0] / Math.max(1, getWidth() - 1), pos[1] / Math.max(1, getHeight() - 1), 0);
        }
        fingers.clear(); owners.clear(); invalidate();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (event.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE) return false;
        device = event.getDeviceId();
        int action = event.getActionMasked(), at = event.getActionIndex();
        if (action == MotionEvent.ACTION_CANCEL) { releaseAll(); return true; }
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            int id = event.getPointerId(at), owner = hit(event.getX(at), event.getY(at));
            owners.put(id, owner);
            if (owner >= 0) key(owner, true);
            else touch(id, MotionEvent.ACTION_DOWN, event.getX(at), event.getY(at), event.getPressure(at));
        } else if (action == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < event.getPointerCount(); ++i) {
                int id = event.getPointerId(i), owner = owners.get(id, -2);
                if (owner == GAME) touch(id, MotionEvent.ACTION_MOVE, event.getX(i), event.getY(i), event.getPressure(i));
                else if (owner >= 0 && !buttons.get(owner).rect.contains(event.getX(i), event.getY(i))) {
                    key(owner, false); owners.put(id, -2);
                }
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) {
            int id = event.getPointerId(at), owner = owners.get(id, -2);
            if (owner >= 0) key(owner, false);
            else if (owner == GAME) touch(id, MotionEvent.ACTION_UP, event.getX(at), event.getY(at), 0);
            owners.delete(id);
            performClick();
        }
        return true;
    }

    @Override public boolean performClick() { return super.performClick(); }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (Control button : buttons) {
            if (hud) {
                if (button.glyph != G_NONE) { drawGlyph(canvas, button); continue; }
                Bitmap img = button.held > 0 && button.down != null ? button.down : button.up;
                if (img != null) {
                    paint.setAlpha(button.label.equals("Reload") && button.held > 0 ? 255 : 235);
                    canvas.drawBitmap(img, null, button.vis, paint);
                    paint.setAlpha(255);
                    continue;
                }
            }
            paint.setColor(button.held > 0 ? 0xCC397BC1 : 0x99202938);
            canvas.drawRoundRect(button.rect, 12, 12, paint);
            paint.setColor(Color.WHITE); paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(button.rect.height() * .28f);
            canvas.drawText(button.label, button.rect.centerX(),
                button.rect.centerY() - (paint.ascent() + paint.descent()) / 2, paint);
        }
    }
}
